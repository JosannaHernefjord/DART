public class Mathtest
{
}
